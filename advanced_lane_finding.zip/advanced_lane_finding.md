
# Advanced Lane Finding Project


## Overview

### Goals
Accurate and robust detection of lane lines, lane curvature, and vehicle position with visual display output.  

###  Implementation Outline
* Compute the camera calibration matrix and distortion coefficients given a set of chessboard images.
* Apply a distortion correction to raw images.
* Use color transforms, gradients, etc., to create a thresholded binary image.
* Apply a perspective transform to rectify binary image ("birds-eye view").
* Detect lane pixels and fit to find the lane boundary.
* Determine the curvature of the lane and vehicle position with respect to center.
* Warp the detected lane boundaries back onto the original image.
* Output visual display of the lane boundaries and numerical estimation of lane curvature and vehicle position.

### Contents
1. `camera_cal` - camera calibration images. 
2. `test_images` - source images for single frame pipeline tests.
3. `output_images` - single frame pipeline test output images. 
4. `project_video.mp4` - pipeline test source video.
5. `output_video.mp4` - pipeline test output video.
6. `README.md` - writeup and documentation.
7. `advanced_lane_finding.ipynb` - implementation code + documentation.

### Libraries
External libraries used in this project.


```python
import numpy as np
import cv2
import os
from moviepy.editor import VideoFileClip
import matplotlib.pyplot as plt
%matplotlib inline
```

### Pyplot Defaults Setup


```python
plt.rcParams['figure.figsize'] = [14,8]
plt.rcParams['figure.frameon'] = False
plt.rcParams['figure.edgecolor'] = 'none'  
plt.rcParams['figure.facecolor'] = 'none' 
plt.rcParams['ytick.left'] = False
plt.rcParams['ytick.right'] = False
plt.rcParams['xtick.bottom'] = False
plt.rcParams['xtick.top'] = False
plt.rcParams['ytick.labelleft'] = False
plt.rcParams['ytick.labelright'] = False
plt.rcParams['xtick.labelbottom'] = False
plt.rcParams['xtick.labeltop'] = False
plt.rcParams['axes.grid'] = False
plt.rcParams['image.cmap'] = 'gray'
plt.rcParams['figure.subplot.hspace'] = 0.01
plt.rcParams['figure.subplot.wspace'] = 0.01
plt.rcParams['image.interpolation'] = 'bilinear'
```

## Camera Calibration

### Load Calibration Images
There are 20 RGB, 720x1280 pixel, JPEG, calibration images.  
Each image contains a 7x10 square celled chessboard pattern with 6x9 inner corners.


```python
CALIB_DIR = './camera_cal/'; fpaths = os.listdir(CALIB_DIR)
imlist = [cv2.imread(CALIB_DIR+fp,cv2.IMREAD_COLOR) for fp in fpaths]
print('image count:',len(imlist)); print('image shape:',imlist[0].shape)
```

    image count: 20
    image shape: (720, 1280, 3)



```python
axlist = plt.subplots(3,3)[1].ravel()
for ax,im in zip(axlist,imlist):
    ax.imshow(im)
```


![png](output_12_0.png)


### Find Chessboard Inner Corners
- The function `cv2.findChessboardCorners()` looks for the 6x9 chessboard pattern inner corners. It's not able to match all calibration images. 
- The corner positions computed with `cv2.findChessboardCorners()` are said to be low percision, altough in practice they're useable as-is. We perform an additional, more computationaly expensive, percision positioning step via `cv2.cornersSubPix()` in an effort to maximize calibration quality.
-  We'll use the green channel to approximate a grayscale image where such input is required.


```python
CBOARD_SHAPE = (9,6)
FINDCB_FLAGS = cv2.CALIB_CB_ADAPTIVE_THRESH+cv2.CALIB_CB_NORMALIZE_IMAGE
SUBPIX_CRITERIA = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)
imgpts = []; mrkdimgs=[]
for img in imlist:
    ret, corners = cv2.findChessboardCorners(img[...,1],CBOARD_SHAPE, flags=FINDCB_FLAGS)        
    if ret is True:
        corners = cv2.cornerSubPix(img[...,1],corners,(11,11),(-1,-1),SUBPIX_CRITERIA) 
        imgpts.append(corners); mrkdimgs.append(img.copy())
print('number of full pattern matches:', len(imgpts))
```

    number of full pattern matches: 17



```python
axlist = plt.subplots(3,3)[1].ravel()
for img,pts,ax in zip(mrkdimgs,imgpts,axlist):
        img = cv2.drawChessboardCorners(img, CBOARD_SHAPE, pts, True)
        ax.imshow(img)
```


![png](output_15_0.png)


### Calibration and Distortion Correction
`cv2.calibrateCamera` and `cv2.getOptimalNewCameraMatrix` are used to perform image registration between the found pattern corner points and an estimate of their supposed positions in an undistorted image. The function computes a matching 3x3 composite transformation matrix (concatenation of rotation, scale perspective, etc transforms) which best describes the pattern distortion in supplied images. The inverse of the distortion transformation matrix is the correction matrix.  

#### Correction Output Calculation
Distortion correction is applied by matrix multiplication of the correction matrix against image coordinate vectors, and then interpolating and copying the values to produce the corrected image. Subsequently, the image is cropped to remove transformation artifcats and scaled back up to produce the output image. 

#### Compute Correction Matrix


```python
objpts = np.zeros((CBOARD_SHAPE[0]*CBOARD_SHAPE[1],3), np.float32)
objpts[:,:2] = np.mgrid[0:CBOARD_SHAPE[0],0:CBOARD_SHAPE[1]].T.reshape(-1,2)
objpts = [objpts]*len(imgpts)
IMG_SHAPE = imlist[0][...,1].shape[::-1]
```


```python
ret, mat, dist, rvecs, tvecs = cv2.calibrateCamera(objpts, imgpts, IMG_SHAPE,None, None)
camrmat, roi = cv2.getOptimalNewCameraMatrix(mat, dist, IMG_SHAPE,1, IMG_SHAPE)
ymin,ymax,xmin,xmax = roi[1],roi[1]+roi[3],roi[0],roi[0]+roi[2]
```

#### Load Source Test Images


```python
TEST_DIR = './test_images/'; fpaths = os.listdir(TEST_DIR)
test = [cv2.imread(TEST_DIR+fp, cv2.IMREAD_COLOR)[...,::-1] for fp in fpaths]
all(ax.imshow(im) for im,ax in zip(test, plt.subplots(3,3)[1].ravel()))
```




    True




![png](output_22_1.png)


#### Apply Correction 


```python
undist = list(cv2.undistort(img, mat,dist,None,camrmat) for img in test)
undist = list(map(lambda img: img[ymin:ymax,xmin:xmax], undist))
undist = list(map(lambda im: cv2.resize(im,(1280,720),interpolation=cv2.INTER_CUBIC), undist))
all(ax.imshow(im) for im,ax in zip(undist, plt.subplots(3,3)[1].ravel()))
```




    True




![png](output_24_1.png)


### Illustration


```python
calib = list(cv2.undistort(img, mat,dist,None,camrmat) for img in imlist)
calib = list(map(lambda img: img[ymin:ymax,xmin:xmax], calib))
calib = list(map(lambda im: cv2.resize(im,(1280,720),interpolation=cv2.INTER_CUBIC), calib))
all(ax.imshow(im) for im,ax in zip(calib, plt.subplots(3,3)[1].ravel()))
```




    True




![png](output_26_1.png)


### Color Space Transformation
We'll convert to the HSV colorspace to perform chroma based segmentation.
Intensity is sensitible to brightness variations, (e.g shadows, specular reflections).
These are also as-hard to separate in RGB space. 
Saturation is not sensitive to brightness variations, so using this channel alone often makes it hard to distinguish between distinct similary saturated colors. 


```python
hsv = list(map(lambda im: cv2.cvtColor(im, cv2.COLOR_RGB2HSV), undist))
```


```python
axlist = plt.subplots(1,3)[1]; axlist[1].set_title('Hue')
all(ax.imshow(im[...,0]) for im,ax in zip(hsv, axlist))
axlist = plt.subplots(1,3)[1]; axlist[1].set_title('Saturation')
all(ax.imshow(im[...,1]) for im,ax in zip(hsv, axlist))
axlist = plt.subplots(1,3)[1]; axlist[1].set_title('Intensity')
all(ax.imshow(im[...,2]) for im,ax in zip(hsv, axlist))
```




    True




![png](output_29_1.png)



![png](output_29_2.png)



![png](output_29_3.png)


### Threshold Binarization
We apply binary thersholding based on HSV color ranges for both white and yellow lane lines. We OR the result to produce our single channel binary output image.


```python
LOW_WHITE = np.array([0, 0, 233], dtype=np.uint8)
HIGH_WHITE = np.array([90,63,255], dtype=np.uint8)
LOW_YELLOW = np.array([15,127,213], dtype=np.uint8)
HIGH_YELLOW = np.array([30,255,255], dtype=np.uint8)
```


```python
wmask = list(map(lambda im: cv2.inRange(im, LOW_WHITE, HIGH_WHITE),hsv))
ymask = list(map(lambda im: cv2.inRange(im, LOW_YELLOW, HIGH_YELLOW),hsv))
thresh = list(map(lambda ymsk,wmsk: cv2.bitwise_or(ymsk, wmsk),ymask, wmask))
binary = thresh
```


```python
all(ax.imshow(im) for im,ax in zip(binary,plt.subplots(3,3)[1].ravel()))
```




    True




![png](output_33_1.png)


## Perspective Transformation
We perform a perspective transformation such that the lane lines are parallel and the ROI fills the whole image. The transformation matrix is computed by finding the lane line endpoints from one of the curve-less test examples. The transformation destination points are the same points with their x coordinates values equalize (i.e lines become parallel).


```python
# Load straight lane lines image
img = binary[7]
# lane line coordinates in a cropped box 
cords = np.argwhere(img>0); cords = cords[cords[:,0]> 575]
lcord, rcord = cords[cords[:,1] < 600], cords[cords[:,1] > 700]
lcord, rcord = lcord[lcord[:,1] > 320], rcord[rcord[:,1] < 1000]
# get lane line extrema coordinates
lmin, lmax = np.min(lcord, axis=0), np.max(lcord, axis=0)
rmin, rmax = np.min(rcord, axis=0), np.max(rcord, axis=0)
p0, p1 = (lmin[1], lmax[0]), (lmax[1], lmin[0])
p2, p3 = (rmin[1], rmin[0]), (rmax[1], rmax[0])
```


```python
src = np.array([p0,p1,p2,p3], dtype=np.float32)
dst = np.array([p0, (p0[0],p1[1]), (p3[0],p2[1]), p3], dtype=np.float32)
```

#### Get Perspective Matrix


```python
Mprsp = cv2.getPerspectiveTransform(src, dst)
iMprsp= cv2.getPerspectiveTransform(dst, src)
```

#### Apply Transformation


```python
persp = list(map(lambda im: cv2.warpPerspective(im,Mprsp,(1280,720),cv2.INTER_CUBIC), binary))
all(ax.imshow(im) for im,ax in zip(persp, plt.subplots(3,3)[1].ravel()))
```




    True




![png](output_40_1.png)


## Polynomial Fit
We divide the images into two halves containing each lanes. 
We then calculate the coordinates of each points in each half. 
Finally, we approximate a 2nd order polynomial function to fit the calculated points. 
`numpy.polyfit()` searches for a polynomial to fit the input points which minimzes the squared error $E = \sum_{j=0}^k |p(x_j) - y_j|^2$.


```python
# get all nonzero point coordinates
contpts = list(map(lambda img: np.argwhere(img>0), persp))
# divide into left and right image side coordinates 
lconts = list(map(lambda pts: pts[pts[...,1]<640].T ,contpts))
rconts = list(map(lambda pts: pts[pts[...,1]>639].T ,contpts))
# if there are no points, puts some that make a straight line
lstrt, rstrt = np.array([[360,361,362],[320,320,320]]), np.array([[360,361,362],[960,960,960]])
lconts = list(map(lambda pts: pts if pts.any() else lstrt , lconts))
rconts = list(map(lambda pts: pts if pts.any() else rstrt , rconts))
# fit a polynomial for the input points of each image
lpoly = list(map(lambda pts: np.poly1d(np.polyfit(pts[0],pts[1],2)),lconts))
rpoly = list(map(lambda pts: np.poly1d(np.polyfit(pts[0],pts[1],2)),rconts))
```


```python
# extrapolate lane line point coordinates by way of the computed polynomial
x = np.arange(0,720,100)
lpts = list(map(lambda lp: np.vstack((lp(x),x)).T.astype(np.int32), lpoly))
rpts = list(map(lambda rp: np.vstack((rp(x),x)).T.astype(np.int32), rpoly))
```

### Polynomials Fit Overlay
We draw the extrapolated polynomial line into a blank image. We then do an inverse-perspective transform on the overlay images to be able to blend them with the input images later.


```python
overlay= []
for i in range(9):
    img = np.zeros((720,1280,3), dtype=np.uint8)
    img = cv2.polylines(img,[lpts[i]], isClosed=False, color=(255,255,255), thickness=43)
    img = cv2.polylines(img,[rpts[i]], isClosed=False, color=(255,255,255), thickness=43)
    pts = np.concatenate((lpts[i],rpts[i][::-1]))
    img = cv2.fillConvexPoly(img,pts,color=(0,0,193))
    img = cv2.warpPerspective(img,iMprsp,(1280,720),flags=cv2.INTER_CUBIC)
    overlay.append(img)
```


```python
all(ax.imshow(im) for im,ax in zip(overlay, plt.subplots(3,3)[1].ravel()))
```




    True




![png](output_46_1.png)


### Curvature Estimation
We'll calculate the curvature radius by way of the following formula:
$$ r(x) = { {\lvert 1+{f'(x)}^2 \rvert}^{3/2} \over {\lvert f''(x) \rvert}  }$$  


```python
METERS_PER_VERTICAL_PIXEL = 30/720.
X_CENTER = 1280/2
radius = []
for i in range(9):
    lpolyder1 = lpoly[i].deriv(m=1); lpolyder2 = lpoly[i].deriv(m=2)
    rpolyder1 = rpoly[i].deriv(m=1); rpolyder2 = rpoly[i].deriv(m=2);
    lrad = (1+lpolyder1(X_CENTER)**2)**1.5/np.abs(lpolyder2(640))
    rrad = (1+rpolyder1(X_CENTER)**2)**1.5/np.abs(rpolyder2(640))
    rad = (lrad+rrad)*METERS_PER_VERTICAL_PIXEL/2
    rad = rad if rad<1000 else 999
    radius.append(rad)
```

### Lane Center Offset Estimation
Lane center is calculated as the mean of mean coordinates of each lane. 


```python
METERS_PER_HORIZONTAL_PIXEL = 3.7/700.
offset = []
for i in range(9):
    center = (np.mean(rpts[i].T[0]) + np.mean(lpts[i].T[0]))/2
    offset.append((center - X_CENTER)*METERS_PER_HORIZONTAL_PIXEL)
```

### Text Overlay


```python
curve_txt = list(map(lambda r: 'Curve radius: '+str(np.round(r,decimals=1))+'m', radius))
offset_txt = list(map(lambda ofst: 'Center offset: '+str(np.round(ofst,decimals=2))+'m', offset))
```


```python
for ovr,ctxt,otxt in zip(overlay, curve_txt,offset_txt):
    cv2.putText(ovr, ctxt,(50, 75),cv2.FONT_HERSHEY_DUPLEX,2.718,(255, 255, 255),2)
    cv2.putText(ovr, otxt,(50, 150),cv2.FONT_HERSHEY_DUPLEX,2.718,(255, 255, 255),2)
```


```python
output = list(map(lambda im,ov: np.maximum(im,ov), overlay,undist))
```


```python
all(ax.imshow(im) for im,ax in zip(output, plt.subplots(3,3)[1].ravel()))
```




    True




![png](output_55_1.png)


## Video Pipeline
The video pipeline is mostly identical to the above process. Major difference is the addition of rudimentary temporal high pass filtering and functional encapsulation.
Images are procesed per video frame. 

### Image Processing


```python
def undistort(img):
    img = cv2.undistort(img, mat,dist,None,camrmat)
    img = img[ymin:ymax,xmin:xmax]
    img = cv2.resize(img,(1280,720),interpolation=cv2.INTER_NEAREST)
    return img
```


```python
def binarize(img):
    img = img.astype(np.uint8)
    img = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
    wmsk = cv2.inRange(img, LOW_WHITE, HIGH_WHITE)
    ymsk = cv2.inRange(img, LOW_YELLOW, HIGH_YELLOW)
    img = cv2.bitwise_or(ymsk, wmsk)
    img = cv2.warpPerspective(img,Mprsp,(1280,720),cv2.INTER_NEAREST)
    return img
```

### Polynomial Fit


```python
def fit_left(img):
    pts = np.argwhere(img>0)
    lpts = pts[pts[...,1]<640].T
    lpts = lpts if lpts.any() else np.array([[360,361,362],[320,320,320]], dtype=np.int32).T
    lpoly = np.poly1d(np.polyfit(lpts[0],lpts[1],2))
    return lpoly
```


```python
def fit_right(img):
    pts = np.argwhere(img>0)
    rpts = pts[pts[...,1]>639].T
    rpts = rpts if rpts.any() else np.array([[360,361,362],[960,960,960]], dtype=np.int32).T
    rpoly = np.poly1d(np.polyfit(rpts[0],rpts[1],2))
    return rpoly
```

#### Temporal Filtering
Instead of just taking the raw calculated values, we reject overly large changes and smooth over smaller ones.


```python
def filter_poly(poly, old_poly):
    diffs = np.abs(poly.coeffs-old_poly.coeffs)
    poly = poly if diffs[0]<0.01 and diffs[1]<0.1 and diffs[2]<10.0 else 0.1*old_poly+0.9*poly
    poly = poly if diffs[0]<0.1 and diffs[1]<1.0 and diffs[2]<100.0 else 0.9*old_poly+0.1*poly
    poly = poly if diffs[0]<1.0 and diffs[1]<10.0 and diffs[2]<1000.0 else old_poly
    return poly
```

### Line Extrapolation


```python
def extrapolate(poly):
    x = np.arange(0,720,100)
    pts = np.vstack((poly(x),x)).T.astype(np.int32)
    return pts
```

### Radius and Offset Calculations
The radius is also filtered over time


```python
def calc_radius(poly):
    fderiv, sderiv = poly.deriv(m=1), poly.deriv(m=2)
    rad = (1+fderiv(X_CENTER)**2)**1.5/np.abs(sderiv(640))
    return rad*METERS_PER_VERTICAL_PIXEL

def filter_radius(l_radius, r_radius, old_radius):
    rad = (l_radius+r_radius)/2.
    rad = rad if rad<999 else 0
    rad = rad if abs(rad-old_radius) < 25 else 0.1*rad + 0.9*old_radius
    return rad
```


```python
def calc_offset(lpts, rpts):
    cntr = (np.mean(rpts.T[0]) + np.mean(lpts.T[0]))/2
    ofst = (cntr - X_CENTER)*METERS_PER_HORIZONTAL_PIXEL
    return ofst
```


```python
def radius_text(radius):
    rad_txt = 'Curve radius: ' + str(np.round(radius,decimals=1)) + 'm'
    return rad_txt
```


```python
def offset_text(offset):
    ofs_txt = 'Center offset: '+ str(np.round(offset,decimals=2)) + 'm'
    return ofs_txt
```

### Drawing Functions


```python
def draw_text(img, offset, radius):
    rad_txt, ofs_txt = radius_text(radius), offset_text(offset)
    cv2.putText(img, rad_txt,(50, 70),cv2.FONT_HERSHEY_DUPLEX,2,(255, 255, 255),2)
    cv2.putText(img, ofs_txt,(50, 140),cv2.FONT_HERSHEY_DUPLEX,2,(255, 255, 255),2)
    return img
```


```python
def draw_lanes(img, lpts, rpts):
    ovr = np.zeros((720,1280,3), dtype=np.int32)
    ovr = cv2.polylines(ovr,[lpts], isClosed=False, color=(255,255,255), thickness=43)
    ovr = cv2.polylines(ovr,[rpts], isClosed=False, color=(255,255,255), thickness=43)
    ovr = cv2.fillConvexPoly(ovr,np.concatenate((lpts,rpts[::-1])),color=(0,0,193))
    ovr = cv2.warpPerspective(ovr,iMprsp,(1280,720),flags=cv2.INTER_NEAREST)
    img = np.maximum(img, ovr)
    return img
```

### Image Processing Main Functions


```python
def process(img):
    img = undistort(img)
    binary = binarize(img)
    left_poly, right_poly = fit_left(binary), fit_right(binary)
    left_poly = filter_poly(left_poly, process.old_left_poly)
    right_poly = filter_poly(right_poly, process.old_right_poly)
    left_points, right_points = extrapolate(left_poly), extrapolate(right_poly)
    left_radius, right_radius = calc_radius(left_poly), calc_radius(right_poly)
    radius = filter_radius(left_radius, right_radius, process.old_radius)
    offset = calc_offset(left_points,right_points)
    # draw 
    img = draw_text(img, offset, radius)
    img = draw_lanes(img, left_points,right_points)
    # update filter params
    process.old_left_poly, process.old_right_poly = left_poly, right_poly
    process.old_radius = radius
    return img

process.old_left_poly = np.poly1d(np.polyfit(np.array([320,320,320]),np.array([360,361,362]),2))
process.old_right_poly = np.poly1d(np.polyfit(np.array([960,960,960]),np.array([360,361,362]),2))
process.old_radius = 100
```

### Video Frame Extraction

#### Project Video


```python
video = VideoFileClip("project_video.mp4")
processed_video = video.fl_image(process)
processed_video.write_videofile("output_project_video.mp4", audio=False)
```

    [MoviePy] >>>> Building video output_project_video.mp4
    [MoviePy] Writing video output_project_video.mp4


    
      0%|          | 0/1261 [00:00<?, ?it/s][A
      0%|          | 2/1261 [00:00<01:41, 12.43it/s][A
      0%|          | 4/1261 [00:00<01:34, 13.29it/s][A
      0%|          | 6/1261 [00:00<01:32, 13.63it/s][A
      1%|          | 8/1261 [00:00<01:30, 13.84it/s][A
      1%|          | 10/1261 [00:00<01:29, 13.94it/s][A
      1%|          | 12/1261 [00:00<01:29, 13.96it/s][A
      1%|          | 14/1261 [00:00<01:28, 14.03it/s][A
      1%|▏         | 16/1261 [00:01<01:29, 13.93it/s][A
      1%|▏         | 18/1261 [00:01<01:29, 13.81it/s][A
      2%|▏         | 20/1261 [00:01<01:30, 13.78it/s][A
      2%|▏         | 22/1261 [00:01<01:30, 13.76it/s][A
      2%|▏         | 24/1261 [00:01<01:30, 13.74it/s][A
      2%|▏         | 26/1261 [00:01<01:29, 13.78it/s][A
      2%|▏         | 28/1261 [00:02<01:29, 13.72it/s][A
      2%|▏         | 30/1261 [00:02<01:29, 13.72it/s][A
      3%|▎         | 32/1261 [00:02<01:29, 13.71it/s][A
      3%|▎         | 34/1261 [00:02<01:29, 13.71it/s][A
      3%|▎         | 36/1261 [00:02<01:29, 13.72it/s][A
      3%|▎         | 38/1261 [00:02<01:29, 13.72it/s][A
      3%|▎         | 40/1261 [00:02<01:29, 13.72it/s][A
      3%|▎         | 42/1261 [00:03<01:28, 13.73it/s][A
      3%|▎         | 44/1261 [00:03<01:29, 13.62it/s][A
      4%|▎         | 46/1261 [00:03<01:29, 13.61it/s][A
      4%|▍         | 48/1261 [00:03<01:29, 13.57it/s][A
      4%|▍         | 50/1261 [00:03<01:29, 13.56it/s][A
      4%|▍         | 52/1261 [00:03<01:29, 13.53it/s][A
      4%|▍         | 54/1261 [00:03<01:29, 13.52it/s][A
      4%|▍         | 56/1261 [00:04<01:29, 13.46it/s][A
      5%|▍         | 58/1261 [00:04<01:29, 13.40it/s][A
      5%|▍         | 60/1261 [00:04<01:29, 13.38it/s][A
      5%|▍         | 62/1261 [00:04<01:29, 13.35it/s][A
      5%|▌         | 64/1261 [00:04<01:29, 13.32it/s][A
      5%|▌         | 66/1261 [00:04<01:29, 13.32it/s][A
      5%|▌         | 68/1261 [00:05<01:29, 13.31it/s][A
      6%|▌         | 70/1261 [00:05<01:29, 13.29it/s][A
      6%|▌         | 72/1261 [00:05<01:29, 13.29it/s][A
      6%|▌         | 74/1261 [00:05<01:29, 13.27it/s][A
      6%|▌         | 76/1261 [00:05<01:29, 13.25it/s][A
      6%|▌         | 78/1261 [00:05<01:29, 13.23it/s][A
      6%|▋         | 80/1261 [00:06<01:29, 13.22it/s][A
      7%|▋         | 82/1261 [00:06<01:29, 13.18it/s][A
      7%|▋         | 84/1261 [00:06<01:29, 13.17it/s][A
      7%|▋         | 86/1261 [00:06<01:29, 13.16it/s][A
      7%|▋         | 88/1261 [00:06<01:29, 13.15it/s][A
      7%|▋         | 90/1261 [00:06<01:29, 13.14it/s][A
      7%|▋         | 92/1261 [00:07<01:29, 13.12it/s][A
      7%|▋         | 94/1261 [00:07<01:28, 13.12it/s][A
      8%|▊         | 96/1261 [00:07<01:28, 13.11it/s][A
      8%|▊         | 98/1261 [00:07<01:28, 13.09it/s][A
      8%|▊         | 100/1261 [00:07<01:28, 13.08it/s][A
      8%|▊         | 102/1261 [00:07<01:28, 13.08it/s][A
      8%|▊         | 104/1261 [00:07<01:28, 13.04it/s][A
      8%|▊         | 106/1261 [00:08<01:28, 12.99it/s][A
      9%|▊         | 108/1261 [00:08<01:28, 12.97it/s][A
      9%|▊         | 110/1261 [00:08<01:28, 12.98it/s][A
      9%|▉         | 112/1261 [00:08<01:28, 12.97it/s][A
      9%|▉         | 114/1261 [00:08<01:28, 12.98it/s][A
      9%|▉         | 116/1261 [00:08<01:28, 12.96it/s][A
      9%|▉         | 118/1261 [00:09<01:28, 12.95it/s][A
     10%|▉         | 120/1261 [00:09<01:28, 12.94it/s][A
     10%|▉         | 122/1261 [00:09<01:28, 12.94it/s][A
     10%|▉         | 124/1261 [00:09<01:27, 12.94it/s][A
     10%|▉         | 126/1261 [00:09<01:27, 12.95it/s][A
     10%|█         | 128/1261 [00:09<01:27, 12.96it/s][A
     10%|█         | 130/1261 [00:10<01:27, 12.96it/s][A
     10%|█         | 132/1261 [00:10<01:27, 12.97it/s][A
     11%|█         | 134/1261 [00:10<01:27, 12.95it/s][A
     11%|█         | 136/1261 [00:10<01:26, 12.95it/s][A
     11%|█         | 138/1261 [00:10<01:26, 12.95it/s][A
     11%|█         | 140/1261 [00:10<01:26, 12.95it/s][A
     11%|█▏        | 142/1261 [00:10<01:26, 12.94it/s][A
     11%|█▏        | 144/1261 [00:11<01:26, 12.93it/s][A
     12%|█▏        | 146/1261 [00:11<01:26, 12.91it/s][A
     12%|█▏        | 148/1261 [00:11<01:26, 12.89it/s][A
     12%|█▏        | 150/1261 [00:11<01:26, 12.89it/s][A
     12%|█▏        | 152/1261 [00:11<01:26, 12.89it/s][A
     12%|█▏        | 154/1261 [00:11<01:25, 12.89it/s][A
     12%|█▏        | 156/1261 [00:12<01:25, 12.89it/s][A
     13%|█▎        | 158/1261 [00:12<01:25, 12.88it/s][A
     13%|█▎        | 160/1261 [00:12<01:25, 12.87it/s][A
     13%|█▎        | 162/1261 [00:12<01:25, 12.87it/s][A
     13%|█▎        | 164/1261 [00:12<01:25, 12.87it/s][A
     13%|█▎        | 166/1261 [00:12<01:25, 12.86it/s][A
     13%|█▎        | 168/1261 [00:13<01:24, 12.86it/s][A
     13%|█▎        | 170/1261 [00:13<01:24, 12.86it/s][A
     14%|█▎        | 172/1261 [00:13<01:24, 12.86it/s][A
     14%|█▍        | 174/1261 [00:13<01:24, 12.86it/s][A
     14%|█▍        | 176/1261 [00:13<01:24, 12.86it/s][A
     14%|█▍        | 178/1261 [00:13<01:24, 12.84it/s][A
     14%|█▍        | 180/1261 [00:14<01:24, 12.84it/s][A
     14%|█▍        | 182/1261 [00:14<01:24, 12.84it/s][A
     15%|█▍        | 184/1261 [00:14<01:23, 12.84it/s][A
     15%|█▍        | 186/1261 [00:14<01:23, 12.84it/s][A
     15%|█▍        | 188/1261 [00:14<01:23, 12.84it/s][A
     15%|█▌        | 190/1261 [00:14<01:23, 12.84it/s][A
     15%|█▌        | 192/1261 [00:14<01:23, 12.85it/s][A
     15%|█▌        | 194/1261 [00:15<01:23, 12.85it/s][A
     16%|█▌        | 196/1261 [00:15<01:22, 12.84it/s][A
     16%|█▌        | 198/1261 [00:15<01:22, 12.84it/s][A
     16%|█▌        | 200/1261 [00:15<01:22, 12.84it/s][A
     16%|█▌        | 202/1261 [00:15<01:22, 12.83it/s][A
     16%|█▌        | 204/1261 [00:15<01:22, 12.80it/s][A
     16%|█▋        | 206/1261 [00:16<01:22, 12.80it/s][A
     16%|█▋        | 208/1261 [00:16<01:22, 12.80it/s][A
     17%|█▋        | 210/1261 [00:16<01:22, 12.79it/s][A
     17%|█▋        | 212/1261 [00:16<01:22, 12.79it/s][A
     17%|█▋        | 214/1261 [00:16<01:21, 12.78it/s][A
     17%|█▋        | 216/1261 [00:16<01:21, 12.78it/s][A
     17%|█▋        | 218/1261 [00:17<01:21, 12.78it/s][A
     17%|█▋        | 220/1261 [00:17<01:21, 12.77it/s][A
     18%|█▊        | 222/1261 [00:17<01:21, 12.77it/s][A
     18%|█▊        | 224/1261 [00:17<01:21, 12.77it/s][A
     18%|█▊        | 226/1261 [00:17<01:21, 12.77it/s][A
     18%|█▊        | 228/1261 [00:17<01:20, 12.77it/s][A
     18%|█▊        | 230/1261 [00:18<01:20, 12.77it/s][A
     18%|█▊        | 232/1261 [00:18<01:20, 12.76it/s][A
     19%|█▊        | 234/1261 [00:18<01:20, 12.76it/s][A
     19%|█▊        | 236/1261 [00:18<01:20, 12.75it/s][A
     19%|█▉        | 238/1261 [00:18<01:20, 12.75it/s][A
     19%|█▉        | 240/1261 [00:18<01:20, 12.75it/s][A
     19%|█▉        | 242/1261 [00:18<01:19, 12.74it/s][A
     19%|█▉        | 244/1261 [00:19<01:19, 12.73it/s][A
     20%|█▉        | 246/1261 [00:19<01:19, 12.73it/s][A
     20%|█▉        | 248/1261 [00:19<01:19, 12.73it/s][A
     20%|█▉        | 250/1261 [00:19<01:19, 12.73it/s][A
     20%|█▉        | 252/1261 [00:19<01:19, 12.73it/s][A
     20%|██        | 254/1261 [00:19<01:19, 12.72it/s][A
     20%|██        | 256/1261 [00:20<01:19, 12.71it/s][A
     20%|██        | 258/1261 [00:20<01:18, 12.71it/s][A
     21%|██        | 260/1261 [00:20<01:18, 12.72it/s][A
     21%|██        | 262/1261 [00:20<01:18, 12.72it/s][A
     21%|██        | 264/1261 [00:20<01:18, 12.72it/s][A
     21%|██        | 266/1261 [00:20<01:18, 12.72it/s][A
     21%|██▏       | 268/1261 [00:21<01:18, 12.72it/s][A
     21%|██▏       | 270/1261 [00:21<01:17, 12.73it/s][A
     22%|██▏       | 272/1261 [00:21<01:17, 12.73it/s][A
     22%|██▏       | 274/1261 [00:21<01:17, 12.73it/s][A
     22%|██▏       | 276/1261 [00:21<01:17, 12.73it/s][A
     22%|██▏       | 278/1261 [00:21<01:17, 12.73it/s][A
     22%|██▏       | 280/1261 [00:21<01:17, 12.73it/s][A
     22%|██▏       | 282/1261 [00:22<01:16, 12.74it/s][A
     23%|██▎       | 284/1261 [00:22<01:16, 12.75it/s][A
     23%|██▎       | 286/1261 [00:22<01:16, 12.74it/s][A
     23%|██▎       | 288/1261 [00:22<01:16, 12.73it/s][A
     23%|██▎       | 290/1261 [00:22<01:16, 12.73it/s][A
     23%|██▎       | 292/1261 [00:22<01:16, 12.73it/s][A
     23%|██▎       | 294/1261 [00:23<01:15, 12.73it/s][A
     23%|██▎       | 296/1261 [00:23<01:15, 12.73it/s][A
     24%|██▎       | 298/1261 [00:23<01:15, 12.74it/s][A
     24%|██▍       | 300/1261 [00:23<01:15, 12.74it/s][A
     24%|██▍       | 302/1261 [00:23<01:15, 12.74it/s][A
     24%|██▍       | 304/1261 [00:23<01:15, 12.74it/s][A
     24%|██▍       | 306/1261 [00:24<01:14, 12.74it/s][A
     24%|██▍       | 308/1261 [00:24<01:14, 12.74it/s][A
     25%|██▍       | 310/1261 [00:24<01:14, 12.75it/s][A
     25%|██▍       | 312/1261 [00:24<01:14, 12.75it/s][A
     25%|██▍       | 314/1261 [00:24<01:14, 12.75it/s][A
     25%|██▌       | 316/1261 [00:24<01:14, 12.75it/s][A
     25%|██▌       | 318/1261 [00:24<01:13, 12.76it/s][A
     25%|██▌       | 320/1261 [00:25<01:13, 12.76it/s][A
     26%|██▌       | 322/1261 [00:25<01:13, 12.76it/s][A
     26%|██▌       | 324/1261 [00:25<01:13, 12.76it/s][A
     26%|██▌       | 326/1261 [00:25<01:13, 12.76it/s][A
     26%|██▌       | 328/1261 [00:25<01:13, 12.76it/s][A
     26%|██▌       | 330/1261 [00:25<01:12, 12.76it/s][A
     26%|██▋       | 332/1261 [00:26<01:12, 12.76it/s][A
     26%|██▋       | 334/1261 [00:26<01:12, 12.76it/s][A
     27%|██▋       | 336/1261 [00:26<01:12, 12.76it/s][A
     27%|██▋       | 338/1261 [00:26<01:12, 12.76it/s][A
     27%|██▋       | 340/1261 [00:26<01:12, 12.76it/s][A
     27%|██▋       | 342/1261 [00:26<01:12, 12.76it/s][A
     27%|██▋       | 344/1261 [00:26<01:11, 12.76it/s][A
     27%|██▋       | 346/1261 [00:27<01:11, 12.76it/s][A
     28%|██▊       | 348/1261 [00:27<01:11, 12.76it/s][A
     28%|██▊       | 350/1261 [00:27<01:11, 12.75it/s][A
     28%|██▊       | 352/1261 [00:27<01:11, 12.76it/s][A
     28%|██▊       | 354/1261 [00:27<01:11, 12.76it/s][A
     28%|██▊       | 356/1261 [00:27<01:10, 12.75it/s][A
     28%|██▊       | 358/1261 [00:28<01:10, 12.75it/s][A
     29%|██▊       | 360/1261 [00:28<01:10, 12.75it/s][A
     29%|██▊       | 362/1261 [00:28<01:10, 12.75it/s][A
     29%|██▉       | 364/1261 [00:28<01:10, 12.75it/s][A
     29%|██▉       | 366/1261 [00:28<01:10, 12.74it/s][A
     29%|██▉       | 368/1261 [00:28<01:10, 12.75it/s][A
     29%|██▉       | 370/1261 [00:29<01:09, 12.75it/s][A
     30%|██▉       | 372/1261 [00:29<01:09, 12.75it/s][A
     30%|██▉       | 374/1261 [00:29<01:09, 12.75it/s][A
     30%|██▉       | 376/1261 [00:29<01:09, 12.75it/s][A
     30%|██▉       | 378/1261 [00:29<01:09, 12.75it/s][A
     30%|███       | 380/1261 [00:29<01:09, 12.75it/s][A
     30%|███       | 382/1261 [00:29<01:08, 12.75it/s][A
     30%|███       | 384/1261 [00:30<01:08, 12.76it/s][A
     31%|███       | 386/1261 [00:30<01:08, 12.76it/s][A
     31%|███       | 388/1261 [00:30<01:08, 12.76it/s][A
     31%|███       | 390/1261 [00:30<01:08, 12.75it/s][A
     31%|███       | 392/1261 [00:30<01:08, 12.75it/s][A
     31%|███       | 394/1261 [00:30<01:08, 12.75it/s][A
     31%|███▏      | 396/1261 [00:31<01:07, 12.75it/s][A
     32%|███▏      | 398/1261 [00:31<01:07, 12.75it/s][A
     32%|███▏      | 400/1261 [00:31<01:07, 12.75it/s][A
     32%|███▏      | 402/1261 [00:31<01:07, 12.76it/s][A
     32%|███▏      | 404/1261 [00:31<01:07, 12.76it/s][A
     32%|███▏      | 406/1261 [00:31<01:06, 12.76it/s][A
     32%|███▏      | 408/1261 [00:31<01:06, 12.76it/s][A
     33%|███▎      | 410/1261 [00:32<01:06, 12.76it/s][A
     33%|███▎      | 412/1261 [00:32<01:06, 12.76it/s][A
     33%|███▎      | 414/1261 [00:32<01:06, 12.76it/s][A
     33%|███▎      | 416/1261 [00:32<01:06, 12.76it/s][A
     33%|███▎      | 418/1261 [00:32<01:06, 12.76it/s][A
     33%|███▎      | 420/1261 [00:32<01:05, 12.75it/s][A
     33%|███▎      | 422/1261 [00:33<01:05, 12.75it/s][A
     34%|███▎      | 424/1261 [00:33<01:05, 12.75it/s][A
     34%|███▍      | 426/1261 [00:33<01:05, 12.74it/s][A
     34%|███▍      | 428/1261 [00:33<01:05, 12.74it/s][A
     34%|███▍      | 430/1261 [00:33<01:05, 12.74it/s][A
     34%|███▍      | 432/1261 [00:33<01:05, 12.74it/s][A
     34%|███▍      | 434/1261 [00:34<01:04, 12.73it/s][A
     35%|███▍      | 436/1261 [00:34<01:04, 12.73it/s][A
     35%|███▍      | 438/1261 [00:34<01:04, 12.73it/s][A
     35%|███▍      | 440/1261 [00:34<01:04, 12.73it/s][A
     35%|███▌      | 442/1261 [00:34<01:04, 12.73it/s][A
     35%|███▌      | 444/1261 [00:34<01:04, 12.72it/s][A
     35%|███▌      | 446/1261 [00:35<01:04, 12.72it/s][A
     36%|███▌      | 448/1261 [00:35<01:03, 12.72it/s][A
     36%|███▌      | 450/1261 [00:35<01:03, 12.72it/s][A
     36%|███▌      | 452/1261 [00:35<01:03, 12.72it/s][A
     36%|███▌      | 454/1261 [00:35<01:03, 12.72it/s][A
     36%|███▌      | 456/1261 [00:35<01:03, 12.72it/s][A
     36%|███▋      | 458/1261 [00:36<01:03, 12.72it/s][A
     36%|███▋      | 460/1261 [00:36<01:02, 12.72it/s][A
     37%|███▋      | 462/1261 [00:36<01:02, 12.72it/s][A
     37%|███▋      | 464/1261 [00:36<01:02, 12.72it/s][A
     37%|███▋      | 466/1261 [00:36<01:02, 12.71it/s][A
     37%|███▋      | 468/1261 [00:36<01:02, 12.71it/s][A
     37%|███▋      | 470/1261 [00:36<01:02, 12.71it/s][A
     37%|███▋      | 472/1261 [00:37<01:02, 12.71it/s][A
     38%|███▊      | 474/1261 [00:37<01:01, 12.70it/s][A
     38%|███▊      | 476/1261 [00:37<01:01, 12.70it/s][A
     38%|███▊      | 478/1261 [00:37<01:01, 12.70it/s][A
     38%|███▊      | 480/1261 [00:37<01:01, 12.69it/s][A
     38%|███▊      | 482/1261 [00:37<01:01, 12.69it/s][A
     38%|███▊      | 484/1261 [00:38<01:01, 12.69it/s][A
     39%|███▊      | 486/1261 [00:38<01:01, 12.68it/s][A
     39%|███▊      | 488/1261 [00:38<01:00, 12.68it/s][A
     39%|███▉      | 490/1261 [00:38<01:00, 12.68it/s][A
     39%|███▉      | 492/1261 [00:38<01:00, 12.68it/s][A
     39%|███▉      | 494/1261 [00:38<01:00, 12.68it/s][A
     39%|███▉      | 496/1261 [00:39<01:00, 12.68it/s][A
     39%|███▉      | 498/1261 [00:39<01:00, 12.68it/s][A
     40%|███▉      | 500/1261 [00:39<01:00, 12.67it/s][A
     40%|███▉      | 502/1261 [00:39<00:59, 12.67it/s][A
     40%|███▉      | 504/1261 [00:39<00:59, 12.67it/s][A
     40%|████      | 506/1261 [00:39<00:59, 12.67it/s][A
     40%|████      | 508/1261 [00:40<00:59, 12.67it/s][A
     40%|████      | 510/1261 [00:40<00:59, 12.66it/s][A
     41%|████      | 512/1261 [00:40<00:59, 12.66it/s][A
     41%|████      | 514/1261 [00:40<00:58, 12.66it/s][A
     41%|████      | 516/1261 [00:40<00:58, 12.66it/s][A
     41%|████      | 518/1261 [00:40<00:58, 12.66it/s][A
     41%|████      | 520/1261 [00:41<00:58, 12.66it/s][A
     41%|████▏     | 522/1261 [00:41<00:58, 12.66it/s][A
     42%|████▏     | 524/1261 [00:41<00:58, 12.66it/s][A
     42%|████▏     | 526/1261 [00:41<00:58, 12.65it/s][A
     42%|████▏     | 528/1261 [00:41<00:57, 12.66it/s][A
     42%|████▏     | 530/1261 [00:41<00:57, 12.65it/s][A
     42%|████▏     | 532/1261 [00:42<00:57, 12.65it/s][A
     42%|████▏     | 534/1261 [00:42<00:57, 12.65it/s][A
     43%|████▎     | 536/1261 [00:42<00:57, 12.65it/s][A
     43%|████▎     | 538/1261 [00:42<00:57, 12.65it/s][A
     43%|████▎     | 540/1261 [00:42<00:57, 12.65it/s][A
     43%|████▎     | 542/1261 [00:42<00:56, 12.65it/s][A
     43%|████▎     | 544/1261 [00:43<00:56, 12.64it/s][A
     43%|████▎     | 546/1261 [00:43<00:56, 12.64it/s][A
     43%|████▎     | 548/1261 [00:43<00:56, 12.64it/s][A
     44%|████▎     | 550/1261 [00:43<00:56, 12.64it/s][A
     44%|████▍     | 552/1261 [00:43<00:56, 12.64it/s][A
     44%|████▍     | 554/1261 [00:43<00:55, 12.65it/s][A
     44%|████▍     | 556/1261 [00:43<00:55, 12.65it/s][A
     44%|████▍     | 558/1261 [00:44<00:55, 12.64it/s][A
     44%|████▍     | 560/1261 [00:44<00:55, 12.64it/s][A
     45%|████▍     | 562/1261 [00:44<00:55, 12.64it/s][A
     45%|████▍     | 564/1261 [00:44<00:55, 12.64it/s][A
     45%|████▍     | 566/1261 [00:44<00:54, 12.64it/s][A
     45%|████▌     | 568/1261 [00:44<00:54, 12.64it/s][A
     45%|████▌     | 570/1261 [00:45<00:54, 12.63it/s][A
     45%|████▌     | 572/1261 [00:45<00:54, 12.62it/s][A
     46%|████▌     | 574/1261 [00:45<00:54, 12.62it/s][A
     46%|████▌     | 576/1261 [00:45<00:54, 12.62it/s][A
     46%|████▌     | 578/1261 [00:45<00:54, 12.61it/s][A
     46%|████▌     | 580/1261 [00:45<00:53, 12.61it/s][A
     46%|████▌     | 582/1261 [00:46<00:53, 12.61it/s][A
     46%|████▋     | 584/1261 [00:46<00:53, 12.61it/s][A
     46%|████▋     | 586/1261 [00:46<00:53, 12.61it/s][A
     47%|████▋     | 588/1261 [00:46<00:53, 12.61it/s][A
     47%|████▋     | 590/1261 [00:46<00:53, 12.60it/s][A
     47%|████▋     | 592/1261 [00:47<00:53, 12.59it/s][A
     47%|████▋     | 594/1261 [00:47<00:52, 12.59it/s][A
     47%|████▋     | 596/1261 [00:47<00:52, 12.59it/s][A
     47%|████▋     | 598/1261 [00:47<00:52, 12.59it/s][A
     48%|████▊     | 600/1261 [00:47<00:52, 12.59it/s][A
     48%|████▊     | 602/1261 [00:47<00:52, 12.59it/s][A
     48%|████▊     | 604/1261 [00:47<00:52, 12.59it/s][A
     48%|████▊     | 606/1261 [00:48<00:52, 12.59it/s][A
     48%|████▊     | 608/1261 [00:48<00:51, 12.59it/s][A
     48%|████▊     | 610/1261 [00:48<00:51, 12.59it/s][A
     49%|████▊     | 612/1261 [00:48<00:51, 12.59it/s][A
     49%|████▊     | 614/1261 [00:48<00:51, 12.58it/s][A
     49%|████▉     | 616/1261 [00:48<00:51, 12.58it/s][A
     49%|████▉     | 618/1261 [00:49<00:51, 12.58it/s][A
     49%|████▉     | 620/1261 [00:49<00:50, 12.58it/s][A
     49%|████▉     | 622/1261 [00:49<00:50, 12.57it/s][A
     49%|████▉     | 624/1261 [00:49<00:50, 12.57it/s][A
     50%|████▉     | 626/1261 [00:49<00:50, 12.57it/s][A
     50%|████▉     | 628/1261 [00:49<00:50, 12.57it/s][A
     50%|████▉     | 630/1261 [00:50<00:50, 12.57it/s][A
     50%|█████     | 632/1261 [00:50<00:50, 12.57it/s][A
     50%|█████     | 634/1261 [00:50<00:49, 12.57it/s][A
     50%|█████     | 636/1261 [00:50<00:49, 12.57it/s][A
     51%|█████     | 638/1261 [00:50<00:49, 12.57it/s][A
     51%|█████     | 640/1261 [00:50<00:49, 12.57it/s][A
     51%|█████     | 642/1261 [00:51<00:49, 12.57it/s][A
     51%|█████     | 644/1261 [00:51<00:49, 12.57it/s][A
     51%|█████     | 646/1261 [00:51<00:48, 12.57it/s][A
     51%|█████▏    | 648/1261 [00:51<00:48, 12.58it/s][A
     52%|█████▏    | 650/1261 [00:51<00:48, 12.58it/s][A
     52%|█████▏    | 652/1261 [00:51<00:48, 12.58it/s][A
     52%|█████▏    | 654/1261 [00:52<00:48, 12.58it/s][A
     52%|█████▏    | 656/1261 [00:52<00:48, 12.58it/s][A
     52%|█████▏    | 658/1261 [00:52<00:47, 12.58it/s][A
     52%|█████▏    | 660/1261 [00:52<00:47, 12.58it/s][A
     52%|█████▏    | 662/1261 [00:52<00:47, 12.58it/s][A
     53%|█████▎    | 664/1261 [00:52<00:47, 12.58it/s][A
     53%|█████▎    | 666/1261 [00:52<00:47, 12.58it/s][A
     53%|█████▎    | 668/1261 [00:53<00:47, 12.58it/s][A
     53%|█████▎    | 670/1261 [00:53<00:46, 12.58it/s][A
     53%|█████▎    | 672/1261 [00:53<00:46, 12.58it/s][A
     53%|█████▎    | 674/1261 [00:53<00:46, 12.58it/s][A
     54%|█████▎    | 676/1261 [00:53<00:46, 12.58it/s][A
     54%|█████▍    | 678/1261 [00:53<00:46, 12.58it/s][A
     54%|█████▍    | 680/1261 [00:54<00:46, 12.58it/s][A
     54%|█████▍    | 682/1261 [00:54<00:46, 12.58it/s][A
     54%|█████▍    | 684/1261 [00:54<00:45, 12.58it/s][A
     54%|█████▍    | 686/1261 [00:54<00:45, 12.58it/s][A
     55%|█████▍    | 688/1261 [00:54<00:45, 12.57it/s][A
     55%|█████▍    | 690/1261 [00:54<00:45, 12.57it/s][A
     55%|█████▍    | 692/1261 [00:55<00:45, 12.57it/s][A
     55%|█████▌    | 694/1261 [00:55<00:45, 12.57it/s][A
     55%|█████▌    | 696/1261 [00:55<00:44, 12.57it/s][A
     55%|█████▌    | 698/1261 [00:55<00:44, 12.57it/s][A
     56%|█████▌    | 700/1261 [00:55<00:44, 12.57it/s][A
     56%|█████▌    | 702/1261 [00:55<00:44, 12.57it/s][A
     56%|█████▌    | 704/1261 [00:55<00:44, 12.57it/s][A
     56%|█████▌    | 706/1261 [00:56<00:44, 12.57it/s][A
     56%|█████▌    | 708/1261 [00:56<00:43, 12.57it/s][A
     56%|█████▋    | 710/1261 [00:56<00:43, 12.57it/s][A
     56%|█████▋    | 712/1261 [00:56<00:43, 12.57it/s][A
     57%|█████▋    | 714/1261 [00:56<00:43, 12.58it/s][A
     57%|█████▋    | 716/1261 [00:56<00:43, 12.58it/s][A
     57%|█████▋    | 718/1261 [00:57<00:43, 12.58it/s][A
     57%|█████▋    | 720/1261 [00:57<00:43, 12.58it/s][A
     57%|█████▋    | 722/1261 [00:57<00:42, 12.58it/s][A
     57%|█████▋    | 724/1261 [00:57<00:42, 12.57it/s][A
     58%|█████▊    | 726/1261 [00:57<00:42, 12.57it/s][A
     58%|█████▊    | 728/1261 [00:57<00:42, 12.58it/s][A
     58%|█████▊    | 730/1261 [00:58<00:42, 12.58it/s][A
     58%|█████▊    | 732/1261 [00:58<00:42, 12.58it/s][A
     58%|█████▊    | 734/1261 [00:58<00:41, 12.58it/s][A
     58%|█████▊    | 736/1261 [00:58<00:41, 12.58it/s][A
     59%|█████▊    | 738/1261 [00:58<00:41, 12.58it/s][A
     59%|█████▊    | 740/1261 [00:58<00:41, 12.58it/s][A
     59%|█████▉    | 742/1261 [00:58<00:41, 12.58it/s][A
     59%|█████▉    | 744/1261 [00:59<00:41, 12.58it/s][A
     59%|█████▉    | 746/1261 [00:59<00:40, 12.59it/s][A
     59%|█████▉    | 748/1261 [00:59<00:40, 12.59it/s][A
     59%|█████▉    | 750/1261 [00:59<00:40, 12.59it/s][A
     60%|█████▉    | 752/1261 [00:59<00:40, 12.59it/s][A
     60%|█████▉    | 754/1261 [00:59<00:40, 12.59it/s][A
     60%|█████▉    | 756/1261 [01:00<00:40, 12.59it/s][A
     60%|██████    | 758/1261 [01:00<00:39, 12.59it/s][A
     60%|██████    | 760/1261 [01:00<00:39, 12.59it/s][A
     60%|██████    | 762/1261 [01:00<00:39, 12.59it/s][A
     61%|██████    | 764/1261 [01:00<00:39, 12.59it/s][A
     61%|██████    | 766/1261 [01:00<00:39, 12.59it/s][A
     61%|██████    | 768/1261 [01:01<00:39, 12.59it/s][A
     61%|██████    | 770/1261 [01:01<00:39, 12.59it/s][A
     61%|██████    | 772/1261 [01:01<00:38, 12.59it/s][A
     61%|██████▏   | 774/1261 [01:01<00:38, 12.59it/s][A
     62%|██████▏   | 776/1261 [01:01<00:38, 12.58it/s][A
     62%|██████▏   | 778/1261 [01:01<00:38, 12.58it/s][A
     62%|██████▏   | 780/1261 [01:01<00:38, 12.58it/s][A
     62%|██████▏   | 782/1261 [01:02<00:38, 12.58it/s][A
     62%|██████▏   | 784/1261 [01:02<00:37, 12.58it/s][A
     62%|██████▏   | 786/1261 [01:02<00:37, 12.58it/s][A
     62%|██████▏   | 788/1261 [01:02<00:37, 12.58it/s][A
     63%|██████▎   | 790/1261 [01:02<00:37, 12.58it/s][A
     63%|██████▎   | 792/1261 [01:02<00:37, 12.59it/s][A
     63%|██████▎   | 794/1261 [01:03<00:37, 12.58it/s][A
     63%|██████▎   | 796/1261 [01:03<00:36, 12.58it/s][A
     63%|██████▎   | 798/1261 [01:03<00:36, 12.58it/s][A
     63%|██████▎   | 800/1261 [01:03<00:36, 12.58it/s][A
     64%|██████▎   | 802/1261 [01:03<00:36, 12.58it/s][A
     64%|██████▍   | 804/1261 [01:03<00:36, 12.58it/s][A
     64%|██████▍   | 806/1261 [01:04<00:36, 12.58it/s][A
     64%|██████▍   | 808/1261 [01:04<00:36, 12.58it/s][A
     64%|██████▍   | 810/1261 [01:04<00:35, 12.58it/s][A
     64%|██████▍   | 812/1261 [01:04<00:35, 12.58it/s][A
     65%|██████▍   | 814/1261 [01:04<00:35, 12.58it/s][A
     65%|██████▍   | 816/1261 [01:04<00:35, 12.57it/s][A
     65%|██████▍   | 818/1261 [01:05<00:35, 12.57it/s][A
     65%|██████▌   | 820/1261 [01:05<00:35, 12.57it/s][A
     65%|██████▌   | 822/1261 [01:05<00:34, 12.57it/s][A
     65%|██████▌   | 824/1261 [01:05<00:34, 12.57it/s][A
     66%|██████▌   | 826/1261 [01:05<00:34, 12.57it/s][A
     66%|██████▌   | 828/1261 [01:05<00:34, 12.57it/s][A
     66%|██████▌   | 830/1261 [01:06<00:34, 12.57it/s][A
     66%|██████▌   | 832/1261 [01:06<00:34, 12.57it/s][A
     66%|██████▌   | 834/1261 [01:06<00:33, 12.57it/s][A
     66%|██████▋   | 836/1261 [01:06<00:33, 12.56it/s][A
     66%|██████▋   | 838/1261 [01:06<00:33, 12.56it/s][A
     67%|██████▋   | 840/1261 [01:06<00:33, 12.56it/s][A
     67%|██████▋   | 842/1261 [01:07<00:33, 12.56it/s][A
     67%|██████▋   | 844/1261 [01:07<00:33, 12.56it/s][A
     67%|██████▋   | 846/1261 [01:07<00:33, 12.56it/s][A
     67%|██████▋   | 848/1261 [01:07<00:32, 12.55it/s][A
     67%|██████▋   | 850/1261 [01:07<00:32, 12.55it/s][A
     68%|██████▊   | 852/1261 [01:07<00:32, 12.55it/s][A
     68%|██████▊   | 854/1261 [01:08<00:32, 12.55it/s][A
     68%|██████▊   | 856/1261 [01:08<00:32, 12.55it/s][A
     68%|██████▊   | 858/1261 [01:08<00:32, 12.55it/s][A
     68%|██████▊   | 860/1261 [01:08<00:31, 12.55it/s][A
     68%|██████▊   | 862/1261 [01:08<00:31, 12.55it/s][A
     69%|██████▊   | 864/1261 [01:08<00:31, 12.55it/s][A
     69%|██████▊   | 866/1261 [01:09<00:31, 12.54it/s][A
     69%|██████▉   | 868/1261 [01:09<00:31, 12.54it/s][A
     69%|██████▉   | 870/1261 [01:09<00:31, 12.54it/s][A
     69%|██████▉   | 872/1261 [01:09<00:31, 12.54it/s][A
     69%|██████▉   | 874/1261 [01:09<00:30, 12.54it/s][A
     69%|██████▉   | 876/1261 [01:09<00:30, 12.54it/s][A
     70%|██████▉   | 878/1261 [01:10<00:30, 12.54it/s][A
     70%|██████▉   | 880/1261 [01:10<00:30, 12.54it/s][A
     70%|██████▉   | 882/1261 [01:10<00:30, 12.54it/s][A
     70%|███████   | 884/1261 [01:10<00:30, 12.54it/s][A
     70%|███████   | 886/1261 [01:10<00:29, 12.54it/s][A
     70%|███████   | 888/1261 [01:10<00:29, 12.54it/s][A
     71%|███████   | 890/1261 [01:10<00:29, 12.54it/s][A
     71%|███████   | 892/1261 [01:11<00:29, 12.54it/s][A
     71%|███████   | 894/1261 [01:11<00:29, 12.54it/s][A
     71%|███████   | 896/1261 [01:11<00:29, 12.54it/s][A
     71%|███████   | 898/1261 [01:11<00:28, 12.54it/s][A
     71%|███████▏  | 900/1261 [01:11<00:28, 12.54it/s][A
     72%|███████▏  | 902/1261 [01:11<00:28, 12.54it/s][A
     72%|███████▏  | 904/1261 [01:12<00:28, 12.54it/s][A
     72%|███████▏  | 906/1261 [01:12<00:28, 12.54it/s][A
     72%|███████▏  | 908/1261 [01:12<00:28, 12.54it/s][A
     72%|███████▏  | 910/1261 [01:12<00:27, 12.54it/s][A
     72%|███████▏  | 912/1261 [01:12<00:27, 12.54it/s][A
     72%|███████▏  | 914/1261 [01:12<00:27, 12.54it/s][A
     73%|███████▎  | 916/1261 [01:13<00:27, 12.54it/s][A
     73%|███████▎  | 918/1261 [01:13<00:27, 12.54it/s][A
     73%|███████▎  | 920/1261 [01:13<00:27, 12.54it/s][A
     73%|███████▎  | 922/1261 [01:13<00:27, 12.54it/s][A
     73%|███████▎  | 924/1261 [01:13<00:26, 12.54it/s][A
     73%|███████▎  | 926/1261 [01:13<00:26, 12.54it/s][A
     74%|███████▎  | 928/1261 [01:13<00:26, 12.54it/s][A
     74%|███████▍  | 930/1261 [01:14<00:26, 12.54it/s][A
     74%|███████▍  | 932/1261 [01:14<00:26, 12.54it/s][A
     74%|███████▍  | 934/1261 [01:14<00:26, 12.54it/s][A
     74%|███████▍  | 936/1261 [01:14<00:25, 12.54it/s][A
     74%|███████▍  | 938/1261 [01:14<00:25, 12.54it/s][A
     75%|███████▍  | 940/1261 [01:14<00:25, 12.54it/s][A
     75%|███████▍  | 942/1261 [01:15<00:25, 12.54it/s][A
     75%|███████▍  | 944/1261 [01:15<00:25, 12.54it/s][A
     75%|███████▌  | 946/1261 [01:15<00:25, 12.54it/s][A
     75%|███████▌  | 948/1261 [01:15<00:24, 12.54it/s][A
     75%|███████▌  | 950/1261 [01:15<00:24, 12.54it/s][A
     75%|███████▌  | 952/1261 [01:15<00:24, 12.54it/s][A
     76%|███████▌  | 954/1261 [01:16<00:24, 12.54it/s][A
     76%|███████▌  | 956/1261 [01:16<00:24, 12.54it/s][A
     76%|███████▌  | 958/1261 [01:16<00:24, 12.54it/s][A
     76%|███████▌  | 960/1261 [01:16<00:24, 12.54it/s][A
     76%|███████▋  | 962/1261 [01:16<00:23, 12.54it/s][A
     76%|███████▋  | 964/1261 [01:16<00:23, 12.54it/s][A
     77%|███████▋  | 966/1261 [01:17<00:23, 12.54it/s][A
     77%|███████▋  | 968/1261 [01:17<00:23, 12.54it/s][A
     77%|███████▋  | 970/1261 [01:17<00:23, 12.54it/s][A
     77%|███████▋  | 972/1261 [01:17<00:23, 12.54it/s][A
     77%|███████▋  | 974/1261 [01:17<00:22, 12.55it/s][A
     77%|███████▋  | 976/1261 [01:17<00:22, 12.55it/s][A
     78%|███████▊  | 978/1261 [01:17<00:22, 12.55it/s][A
     78%|███████▊  | 980/1261 [01:18<00:22, 12.55it/s][A
     78%|███████▊  | 982/1261 [01:18<00:22, 12.55it/s][A
     78%|███████▊  | 984/1261 [01:18<00:22, 12.55it/s][A
     78%|███████▊  | 986/1261 [01:18<00:21, 12.55it/s][A
     78%|███████▊  | 988/1261 [01:18<00:21, 12.55it/s][A
     79%|███████▊  | 990/1261 [01:18<00:21, 12.55it/s][A
     79%|███████▊  | 992/1261 [01:19<00:21, 12.55it/s][A
     79%|███████▉  | 994/1261 [01:19<00:21, 12.54it/s][A
     79%|███████▉  | 996/1261 [01:19<00:21, 12.54it/s][A
     79%|███████▉  | 998/1261 [01:19<00:20, 12.54it/s][A
     79%|███████▉  | 1000/1261 [01:19<00:20, 12.54it/s][A
     79%|███████▉  | 1002/1261 [01:19<00:20, 12.54it/s][A
     80%|███████▉  | 1004/1261 [01:20<00:20, 12.54it/s][A
     80%|███████▉  | 1006/1261 [01:20<00:20, 12.54it/s][A
     80%|███████▉  | 1008/1261 [01:20<00:20, 12.54it/s][A
     80%|████████  | 1010/1261 [01:20<00:20, 12.54it/s][A
     80%|████████  | 1012/1261 [01:20<00:19, 12.54it/s][A
     80%|████████  | 1014/1261 [01:20<00:19, 12.54it/s][A
     81%|████████  | 1016/1261 [01:21<00:19, 12.54it/s][A
     81%|████████  | 1018/1261 [01:21<00:19, 12.54it/s][A
     81%|████████  | 1020/1261 [01:21<00:19, 12.54it/s][A
     81%|████████  | 1022/1261 [01:21<00:19, 12.54it/s][A
     81%|████████  | 1024/1261 [01:21<00:18, 12.54it/s][A
     81%|████████▏ | 1026/1261 [01:21<00:18, 12.54it/s][A
     82%|████████▏ | 1028/1261 [01:22<00:18, 12.53it/s][A
     82%|████████▏ | 1030/1261 [01:22<00:18, 12.53it/s][A
     82%|████████▏ | 1032/1261 [01:22<00:18, 12.53it/s][A
     82%|████████▏ | 1034/1261 [01:22<00:18, 12.54it/s][A
     82%|████████▏ | 1036/1261 [01:22<00:17, 12.54it/s][A
     82%|████████▏ | 1038/1261 [01:22<00:17, 12.54it/s][A
     82%|████████▏ | 1040/1261 [01:22<00:17, 12.54it/s][A
     83%|████████▎ | 1042/1261 [01:23<00:17, 12.54it/s][A
     83%|████████▎ | 1044/1261 [01:23<00:17, 12.53it/s][A
     83%|████████▎ | 1046/1261 [01:23<00:17, 12.53it/s][A
     83%|████████▎ | 1048/1261 [01:23<00:16, 12.53it/s][A
     83%|████████▎ | 1050/1261 [01:23<00:16, 12.54it/s][A
     83%|████████▎ | 1052/1261 [01:23<00:16, 12.54it/s][A
     84%|████████▎ | 1054/1261 [01:24<00:16, 12.53it/s][A
     84%|████████▎ | 1056/1261 [01:24<00:16, 12.53it/s][A
     84%|████████▍ | 1058/1261 [01:24<00:16, 12.53it/s][A
     84%|████████▍ | 1060/1261 [01:24<00:16, 12.53it/s][A
     84%|████████▍ | 1062/1261 [01:24<00:15, 12.53it/s][A
     84%|████████▍ | 1064/1261 [01:24<00:15, 12.53it/s][A
     85%|████████▍ | 1066/1261 [01:25<00:15, 12.53it/s][A
     85%|████████▍ | 1068/1261 [01:25<00:15, 12.53it/s][A
     85%|████████▍ | 1070/1261 [01:25<00:15, 12.52it/s][A
     85%|████████▌ | 1072/1261 [01:25<00:15, 12.52it/s][A
     85%|████████▌ | 1074/1261 [01:25<00:14, 12.52it/s][A
     85%|████████▌ | 1076/1261 [01:25<00:14, 12.52it/s][A
     85%|████████▌ | 1078/1261 [01:26<00:14, 12.52it/s][A
     86%|████████▌ | 1080/1261 [01:26<00:14, 12.51it/s][A
     86%|████████▌ | 1082/1261 [01:26<00:14, 12.51it/s][A
     86%|████████▌ | 1084/1261 [01:26<00:14, 12.51it/s][A
     86%|████████▌ | 1086/1261 [01:26<00:13, 12.51it/s][A
     86%|████████▋ | 1088/1261 [01:27<00:13, 12.51it/s][A
     86%|████████▋ | 1090/1261 [01:27<00:13, 12.50it/s][A
     87%|████████▋ | 1092/1261 [01:27<00:13, 12.50it/s][A
     87%|████████▋ | 1094/1261 [01:27<00:13, 12.50it/s][A
     87%|████████▋ | 1096/1261 [01:27<00:13, 12.49it/s][A
     87%|████████▋ | 1098/1261 [01:27<00:13, 12.49it/s][A
     87%|████████▋ | 1100/1261 [01:28<00:12, 12.49it/s][A
     87%|████████▋ | 1102/1261 [01:28<00:12, 12.49it/s][A
     88%|████████▊ | 1104/1261 [01:28<00:12, 12.48it/s][A
     88%|████████▊ | 1106/1261 [01:28<00:12, 12.48it/s][A
     88%|████████▊ | 1108/1261 [01:28<00:12, 12.48it/s][A
     88%|████████▊ | 1110/1261 [01:28<00:12, 12.48it/s][A
     88%|████████▊ | 1112/1261 [01:29<00:11, 12.48it/s][A
     88%|████████▊ | 1114/1261 [01:29<00:11, 12.48it/s][A
     89%|████████▊ | 1116/1261 [01:29<00:11, 12.48it/s][A
     89%|████████▊ | 1118/1261 [01:29<00:11, 12.47it/s][A
     89%|████████▉ | 1120/1261 [01:29<00:11, 12.47it/s][A
     89%|████████▉ | 1122/1261 [01:29<00:11, 12.47it/s][A
     89%|████████▉ | 1124/1261 [01:30<00:10, 12.47it/s][A
     89%|████████▉ | 1126/1261 [01:30<00:10, 12.47it/s][A
     89%|████████▉ | 1128/1261 [01:30<00:10, 12.47it/s][A
     90%|████████▉ | 1130/1261 [01:30<00:10, 12.47it/s][A
     90%|████████▉ | 1132/1261 [01:30<00:10, 12.47it/s][A
     90%|████████▉ | 1134/1261 [01:30<00:10, 12.47it/s][A
     90%|█████████ | 1136/1261 [01:31<00:10, 12.47it/s][A
     90%|█████████ | 1138/1261 [01:31<00:09, 12.47it/s][A
     90%|█████████ | 1140/1261 [01:31<00:09, 12.47it/s][A
     91%|█████████ | 1142/1261 [01:31<00:09, 12.47it/s][A
     91%|█████████ | 1144/1261 [01:31<00:09, 12.47it/s][A
     91%|█████████ | 1146/1261 [01:31<00:09, 12.47it/s][A
     91%|█████████ | 1148/1261 [01:32<00:09, 12.47it/s][A
     91%|█████████ | 1150/1261 [01:32<00:08, 12.47it/s][A
     91%|█████████▏| 1152/1261 [01:32<00:08, 12.46it/s][A
     92%|█████████▏| 1154/1261 [01:32<00:08, 12.46it/s][A
     92%|█████████▏| 1156/1261 [01:32<00:08, 12.46it/s][A
     92%|█████████▏| 1158/1261 [01:32<00:08, 12.46it/s][A
     92%|█████████▏| 1160/1261 [01:33<00:08, 12.46it/s][A
     92%|█████████▏| 1162/1261 [01:33<00:07, 12.46it/s][A
     92%|█████████▏| 1164/1261 [01:33<00:07, 12.45it/s][A
     92%|█████████▏| 1166/1261 [01:33<00:07, 12.45it/s][A
     93%|█████████▎| 1168/1261 [01:33<00:07, 12.45it/s][A
     93%|█████████▎| 1170/1261 [01:33<00:07, 12.45it/s][A
     93%|█████████▎| 1172/1261 [01:34<00:07, 12.45it/s][A
     93%|█████████▎| 1174/1261 [01:34<00:06, 12.44it/s][A
     93%|█████████▎| 1176/1261 [01:34<00:06, 12.44it/s][A
     93%|█████████▎| 1178/1261 [01:34<00:06, 12.44it/s][A
     94%|█████████▎| 1180/1261 [01:34<00:06, 12.44it/s][A
     94%|█████████▎| 1182/1261 [01:35<00:06, 12.44it/s][A
     94%|█████████▍| 1184/1261 [01:35<00:06, 12.44it/s][A
     94%|█████████▍| 1186/1261 [01:35<00:06, 12.44it/s][A
     94%|█████████▍| 1188/1261 [01:35<00:05, 12.44it/s][A
     94%|█████████▍| 1190/1261 [01:35<00:05, 12.44it/s][A
     95%|█████████▍| 1192/1261 [01:35<00:05, 12.44it/s][A
     95%|█████████▍| 1194/1261 [01:36<00:05, 12.44it/s][A
     95%|█████████▍| 1196/1261 [01:36<00:05, 12.44it/s][A
     95%|█████████▌| 1198/1261 [01:36<00:05, 12.43it/s][A
     95%|█████████▌| 1200/1261 [01:36<00:04, 12.43it/s][A
     95%|█████████▌| 1202/1261 [01:36<00:04, 12.43it/s][A
     95%|█████████▌| 1204/1261 [01:36<00:04, 12.43it/s][A
     96%|█████████▌| 1206/1261 [01:36<00:04, 12.43it/s][A
     96%|█████████▌| 1208/1261 [01:37<00:04, 12.43it/s][A
     96%|█████████▌| 1210/1261 [01:37<00:04, 12.43it/s][A
     96%|█████████▌| 1212/1261 [01:37<00:03, 12.43it/s][A
     96%|█████████▋| 1214/1261 [01:37<00:03, 12.43it/s][A
     96%|█████████▋| 1216/1261 [01:37<00:03, 12.43it/s][A
     97%|█████████▋| 1218/1261 [01:37<00:03, 12.43it/s][A
     97%|█████████▋| 1220/1261 [01:38<00:03, 12.43it/s][A
     97%|█████████▋| 1222/1261 [01:38<00:03, 12.43it/s][A
     97%|█████████▋| 1224/1261 [01:38<00:02, 12.43it/s][A
     97%|█████████▋| 1226/1261 [01:38<00:02, 12.43it/s][A
     97%|█████████▋| 1228/1261 [01:38<00:02, 12.43it/s][A
     98%|█████████▊| 1230/1261 [01:38<00:02, 12.43it/s][A
     98%|█████████▊| 1232/1261 [01:39<00:02, 12.43it/s][A
     98%|█████████▊| 1234/1261 [01:39<00:02, 12.43it/s][A
     98%|█████████▊| 1236/1261 [01:39<00:02, 12.43it/s][A
     98%|█████████▊| 1238/1261 [01:39<00:01, 12.43it/s][A
     98%|█████████▊| 1240/1261 [01:39<00:01, 12.43it/s][A
     98%|█████████▊| 1242/1261 [01:39<00:01, 12.43it/s][A
     99%|█████████▊| 1244/1261 [01:40<00:01, 12.43it/s][A
     99%|█████████▉| 1246/1261 [01:40<00:01, 12.43it/s][A
     99%|█████████▉| 1248/1261 [01:40<00:01, 12.43it/s][A
     99%|█████████▉| 1250/1261 [01:40<00:00, 12.43it/s][A
     99%|█████████▉| 1252/1261 [01:40<00:00, 12.43it/s][A
     99%|█████████▉| 1254/1261 [01:40<00:00, 12.43it/s][A
    100%|█████████▉| 1256/1261 [01:41<00:00, 12.43it/s][A
    100%|█████████▉| 1258/1261 [01:41<00:00, 12.43it/s][A
    100%|█████████▉| 1260/1261 [01:41<00:00, 12.43it/s][A
    [A

    [MoviePy] Done.
    [MoviePy] >>>> Video ready: output_project_video.mp4 
    


## Discussion

The model is sensitive to a variety of variables: day/night conditions, shadows, specular reflections, traffic, steep inclines and declines, partial or total lack of markings, weather artifacts, and many others.  

There's definitely a lot of work that can be done further. For example, ensemble methods like combining edge detection and chroma segmentation result. Or advanced temporal methods looking at various changes over time. 
